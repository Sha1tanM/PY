import html
import cgi

from connect import connection


form = cgi.FieldStorage()

login = form.getfirst("login")
password = form.getfirst("password")

login = html.escape(login)
password= html.escape(password)

with connection.cursor() as cursor:
    select_query = f"SELECT * FROM doctors inner join positions on doctors.id_pos=positions.id WHERE login = '{login}' AND password = '{password}'"
    cursor.execute(select_query)
    res = cursor.fetchone()

print("Content-type: text/html\n")
print("""<!DOCTYPE HTML>
       <html>
       <head>
           <meta charset="utf-8">
           <title>Личный кабинет</title>
           <link rel="stylesheet" href="../style.css">
       </head>
       <body id='cats'>  """)
# Вывод полученных значений


if res:
    print("<h4>Добро пожаловать!</h4>")
    print("<p>Фамилия: {}</p>".format(res['fname']))
    print("<p>Имя: {}</p>".format(res['lname']))
    print("<p>Отчество: {}</p>".format(res['sname']))
    print("<p>Номер телефона: {}</p>".format(res['phon']))
    print("<p>Почта: {}</p>".format(res['email']))
    print("<p>Паспорт: {}</p>".format(res['paspord']))
    print("<p>Образование: {}</p>".format(res['education']))
    print("<p>Должность: {}</p>".format(res['name_pos']))
    print("<p>Логин: {}</p>".format(res['login']))
    print("<p>Логин: {}</p>".format(res['login']))
    print(f"<form  action='password.py'><input type='submit' value='Редактировать личные данные'>  "
          f"<input type='text' name='doc_id' value='{res['id']}' > </form> ")
else:

    print(f"Ошибка в логине или пароле! <a href='../index.html'>Попробовать еще раз</a> ")


