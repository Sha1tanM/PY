import cgi
import html

form = cgi.FieldStorage()
doc_id = html.escape(form.getfirst("doc_id", ""))

print("Content-type: text/html\n")
print("""<!DOCTYPE HTML>
       <html>
       <head>
           <meta charset="utf-8">
           <title>Обработка данных форм</title>
           <link rel="stylesheet" href="../style.css">
       </head>
       <body id='cats'> """)
print("""<form  action="savedatadoc.py">
        <label for="new_phon">Новый телефон:</label>
        <input type="text" name="new_phon" id="new_phon">
        <br>
        <label for="new_email">Новый Email:</label>
        <input type="email" name="new_email" id="new_email">
        <br>
        <label for="new_passport">Новые паспортные данные:</label>
        <input type="text" name="new_paspord" id="new_paspord">
        <br>
        <label for="new_education">Новые образование:</label>
        <input type="text" name="new_education" id="new_education">
          
        <br>
        <input type="submit" value="Сохранить изменения">""")
print(f" <input type='submit' name='doc_id' value='{doc_id}'>")
print("</form>")

