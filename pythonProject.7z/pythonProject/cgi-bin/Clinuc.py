from connect import connection


def update_docs(new_phon, new_email, new_paspord, new_education,  doc_id):
    if new_phon:
        # Обновляем данные в базе данных
        with connection.cursor() as cursor:
            update_query = f"UPDATE doctors SET phon = '{new_phon}' WHERE id='{doc_id}';"
            cursor.execute(update_query)
            connection.commit()
    if new_email:
        with connection.cursor() as cursor:
            update_query = f"UPDATE doctors SET email = '{new_email}' WHERE id='{doc_id}';"
            cursor.execute(update_query)
            connection.commit()
    if new_paspord:
        with connection.cursor() as cursor:
            update_query = f"UPDATE doctors SET paspord = '{new_paspord}' WHERE id='{doc_id}';"
            cursor.execute(update_query)
            connection.commit()

    if new_education:
        with connection.cursor() as cursor:
            update_query = f"UPDATE doctors SET education = '{new_education}' WHERE id='{doc_id}';"
            cursor.execute(update_query)
            connection.commit()
