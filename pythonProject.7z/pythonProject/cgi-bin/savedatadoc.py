import cgi
import html
# from Clinuc import update_docs
from connect import connection

form = cgi.FieldStorage()
doc_id = html.escape(form.getfirst("doc_id", ""))
new_phon = html.escape(form.getfirst("new_phon", ""))
new_email = html.escape(form.getfirst("new_email", ""))
new_paspord = html.escape(form.getfirst("new_paspord", ""))
new_education = html.escape(form.getfirst("new_education", ""))


# Если форма была отправлена, извлекаем новые данные
#

print("Content-type: text/html\n")
print("""<!DOCTYPE HTML>
       <html>
       <head>
           <meta charset="utf-8">
           <title>Обработка данных форм</title>
           <link rel="stylesheet" href="../style.css">
       </head>
       <body id='cats'> <h2>Super</h2>""")
print(f"{new_email}")


# def update_docs(new_phon, new_email, new_paspord, new_education,  doc_id):
if new_phon:
    # Обновляем данные в базе данных
    with connection.cursor() as cursor:
        update_query = f"UPDATE doctors SET phon = '{new_phon}' WHERE id='{doc_id}';"
        cursor.execute(update_query)
        connection.commit()
if new_email:
    with connection.cursor() as cursor:
        update_query = f"UPDATE doctors SET email = '{new_email}' WHERE id='{doc_id}';"
        cursor.execute(update_query)
        connection.commit()
if new_paspord:
    with connection.cursor() as cursor:
        update_query = f"UPDATE doctors SET paspord = '{new_paspord}' WHERE id='{doc_id}';"
        cursor.execute(update_query)
        connection.commit()

if new_education:
    with connection.cursor() as cursor:
        update_query = f"UPDATE doctors SET education = '{new_education}' WHERE id='{doc_id}';"
        cursor.execute(update_query)
        connection.commit()


# update_docs(new_phon, new_email, new_paspord, new_education, doc_id)